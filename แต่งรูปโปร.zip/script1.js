/**
 * script1.js - Advanced Voice AI Enhancement
 * เวอร์ชันซับซ้อน: รองรับบริบท, การปรับค่าแบบสัมพัทธ์, การยืนยัน, และการเรียนรู้อัตโนมัติ
 * วางในโฟลเดอร์เดียวกับ index.html และโหลด AFTER script.js
 */

(function() {
    const waitForEditor = setInterval(() => {
        if (window.editor && window.editor.recognition) {
            clearInterval(waitForEditor);
            enhanceVoiceAI();
        }
    }, 100);

    function enhanceVoiceAI() {
        const editor = window.editor;
        if (!editor) return;

        // ---------- ระบบ AI ขั้นสูง ----------
        // 1. ความสามารถในการเข้าใจค่าสัมพัทธ์ (เพิ่ม/ลด)
        // 2. การจำประวัติสนทนาสำหรับ contextual follow-up
        // 3. การสุ่มคำตอบแบบไดนามิกตามสถานะ
        // 4. การเรียนรู้คำพ้องความหมายใหม่ (user-defined synonyms)
        // 5. Fallback ให้ถามผู้ใช้เมื่อไม่เข้าใจ

        // ---------- ฐานข้อมูลความรู้ ----------
        const aiKnowledge = {
            // ชุดคำทักทายและ farewell (ขยาย)
            greetings: ["สวัสดี", "หวัดดี", "hello", "ฮัลโหล", "hey", "ไง"],
            farewells: ["ลาก่อน", "บาย", "bye", "แล้วเจอกัน", "ไปละ"],
            thanks: ["ขอบคุณ", "thank", "thanks", "ขอบใจ", "แค่นี้ก่อน"],
            
            // คำพ้องความหมายของ actions (ขยายโดยอัตโนมัติผ่านการเรียนรู้)
            synonyms: {
                "sharpen": ["เพิ่มความคมชัด", "ชาร์ป", "ทำให้คม", "ชัดขึ้น", "ชาร์ปขึ้น", "เพิ่มชาร์ป", "ปรับความคม"],
                "blur": ["เบลอ", "ทำให้เบลอ", "ละลาย", "ฟุ้ง", "ลดความคม"],
                "brightness": ["ความสว่าง", "สว่าง", "เพิ่มความสว่าง", "ลดความสว่าง", "brightness", "สว่างขึ้น", "มืดลง"],
                "contrast": ["คอนทราสต์", "ความต่าง", "contrast", "เพิ่มคอนทราสต์", "ลดคอนทราสต์"],
                "saturation": ["ความอิ่มตัว", "สีจัด", "saturation", "อิ่มตัว", "เพิ่มความอิ่ม", "สีสด"],
                "undo": ["ย้อนกลับ", "เลิกทำ", "undo", "กลับคืน", "ย้อน", "เลิก"],
                "redo": ["ทำซ้ำ", "redo", "ทำอีก", "ซ้ำ"],
                "reset": ["รีเซ็ต", "คืนค่า", "reset", "เริ่มใหม่", "ล้าง"],
                "removeBg": ["ลบพื้นหลัง", "ตัดพื้นหลัง", "remove background", "เปลี่ยนพื้นหลัง", "ถอดพื้น"],
                "save": ["บันทึก", "เซฟ", "save", "เก็บภาพ", "เซฟไฟล์"],
                "autoEnhance": ["ปรับอัตโนมัติ", "ออโต้", "auto", "ปรับภาพอัตโนมัติ", "enhance"],
                "zoom": ["ซูม", "ขยาย", "zoom in", "zoom out", "缩小", "放大"],
                "upload": ["อัปโหลด", "เพิ่มภาพ", "เลือกภาพ", "upload image", "อัปภาพ"],
                "help": ["ช่วยเหลือ", "help", "แนะนำ", "คำสั่ง", "ทำอะไรได้บ้าง"]
            },
            
            // หน่วยที่สามารถปรับค่าได้ (สำหรับ relative adjustment)
            adjustables: {
                "amount": { min: 0, max: 200, step: 5, default: 50, sliderId: "amountSlider" },
                "radius": { min: 0.5, max: 5, step: 0.1, default: 1, sliderId: "radiusSlider" },
                "threshold": { min: 0, max: 50, step: 1, default: 10, sliderId: "thresholdSlider" },
                "saturation": { min: 0, max: 200, step: 5, default: 100, sliderId: "saturationSlider" },
                "brightness": { min: -100, max: 100, step: 5, default: 0, sliderId: "brightnessSlider" },
                "contrast": { min: -50, max: 50, step: 2, default: 0, sliderId: "contrastSlider" }
            }
        };

        // เก็บประวัติสนทนา (สูงสุด 5 รายการ)
        let conversationHistory = [];
        let lastIntent = null;
        let lastEntities = null;
        let pendingConfirmation = null;   // { intent, entities, callback }
        
        // เก็บคำพ้องความหมายที่ผู้ใช้เพิ่มเอง (เรียนรู้)
        let userSynonyms = JSON.parse(localStorage.getItem('voice_synonyms') || '{}');

        // ผสาน synonyms
        function getAllSynonyms() {
            const merged = { ...aiKnowledge.synonyms };
            for (let [key, values] of Object.entries(userSynonyms)) {
                if (!merged[key]) merged[key] = [];
                merged[key].push(...values);
            }
            return merged;
        }

        // ---------- ตอบกลับแบบสุ่มและมีไดนามิกตามบริบท ----------
        const aiResponses = {
            greeting: ["สวัสดีค่ะ พร้อมช่วยเหลือ", "ยินดีให้บริการนะคะ", "มีอะไรให้ช่วยไหมคะ", "ว่าไงคะ พูดมาได้เลย"],
            farewell: ["ลาก่อนนะคะ", "ไว้เจอกันใหม่", "แล้วพบกันใหม่ค่ะ", "บาย ๆ ค่ะ"],
            confirm: ["เรียบร้อยค่ะ", "ดำเนินการให้แล้วนะคะ", "เสร็จสิ้นค่ะ", "ตามนั้นเลยค่ะ", "ปรับให้แล้วค่ะ"],
            askRepeat: ["ขอโทษนะคะ พูดอีกครั้งได้ไหม", "ไม่ค่อยชัด รบกวนพูดอีกที", "ได้ยินไม่ถนัด กรุณาพูดอีกครั้ง", "ได้ยินไม่ชัดเจน ลองพูดใหม่นะคะ"],
            unknown: ["ยังไม่เข้าใจคำสั่งนี้ ลองพูด 'ช่วยเหลือ' ดูนะคะ", "ไม่ทราบคำสั่งค่ะ พูด 'ช่วยเหลือ' เพื่อดูคำสั่งที่มี", "ขออภัย ยังไม่รู้จักคำสั่งนี้", "听不懂 ลองพูดเป็นคำสั่งที่แนะนำ"],
            help: ["คำสั่งที่ใช้ได้: ปรับความคมชัด, เพิ่มความสว่าง, ลบพื้นหลัง, บันทึกภาพ, ย้อนกลับ, ทำซ้ำ, รีเซ็ต, ตั้งค่าความคมชัด 80, ตั้งค่ารัศมี 1.5, ปรับความอิ่มตัว 120, ปรับคอนทราสต์ 20, ซูม ฯลฯ"],
            thank: ["ยินดีค่ะ", "ด้วยความยินดี", "ไม่เป็นไรนะคะ", "ขอบคุณที่ใช้บริการค่ะ"],
            needConfirmation: ["คุณต้องการให้ปรับ {value} หรือไม่? ตอบว่า 'ใช่' หรือ 'ไม่'", "ยืนยันการปรับ {action} ค่ะ? พูด 'ใช่' เพื่อดำเนินการ"],
            cantAdjustRelative: ["ไม่รู้ค่าปัจจุบัน กรุณาระบุตัวเลขเต็ม เช่น 'เพิ่มความคมชัดเป็น 70'", "บอกมาเป็นตัวเลขจะดีกว่าค่ะ"],
            learnSynonym: ["บันทึกคำ '{word}' เป็นความหมายเดียวกับ '{action}' แล้ว", "เข้าใจแล้วว่า '{word}' หมายถึง {action}"],
            askWhichAction: ["คุณต้องการปรับอะไร? (ความคมชัด, ความสว่าง, คอนทราสต์, ความอิ่มตัว)", "ปรับค่าไหนดีคะ? พูด 'ความคมชัด' หรือ 'ความสว่าง'"]
        };

        function randomResponse(category, placeholders = {}) {
            let arr = aiResponses[category] || aiResponses.unknown;
            let text = arr[Math.floor(Math.random() * arr.length)];
            for (let [key, val] of Object.entries(placeholders)) {
                text = text.replace(`{${key}}`, val);
            }
            return text;
        }

        // ฟังก์ชันอัปเดต slider และแสดงผล
        function updateSliderValue(sliderId, value) {
            const slider = document.getElementById(sliderId);
            if (slider) {
                slider.value = value;
                if (slider.oninput) slider.oninput(); // trigger event
                if (editor.updateSliderDisplays) editor.updateSliderDisplays();
                return true;
            }
            return false;
        }

        function getCurrentSliderValue(sliderId) {
            const slider = document.getElementById(sliderId);
            return slider ? parseFloat(slider.value) : null;
        }

        // ---------- การปรับค่าแบบสัมพัทธ์ (เพิ่มขึ้น/ลดลง) ----------
        function parseRelativeAdjust(text, paramName) {
            // รูปแบบ: "เพิ่มความคมชัดขึ้น 10%" , "ลดความสว่าง 5 หน่วย", "เพิ่มความอิ่มตัวอีกหน่อย"
            const lower = text.toLowerCase();
            const cfg = aiKnowledge.adjustables[paramName];
            if (!cfg) return null;
            
            let amount = null;
            let isIncrease = null;
            
            if (/(เพิ่ม|มากขึ้น|มากขึ้นอีก|เพิ่มขึ้น|ขึ้น|\+)/.test(lower)) isIncrease = true;
            else if (/(ลด|ลดลง|น้อยลง|ลบ|\-)/.test(lower)) isIncrease = false;
            else return null;
            
            // ดึงตัวเลข (อาจเป็น "10", "5%" , "อีก 15")
            let match = lower.match(/(\d+(?:\.\d+)?)/);
            if (match) {
                amount = parseFloat(match[1]);
                // ปรับให้อยู่ใน step
                amount = Math.round(amount / cfg.step) * cfg.step;
            } else {
                // ถ้าไม่มีตัวเลข ให้ใช้ค่า step เป็น default
                amount = cfg.step;
            }
            if (isIncrease === false) amount = -amount;
            
            return amount;
        }
        
        // ใช้ค่าปัจจุบัน + delta
        async function applyRelativeAdjust(paramName, delta, intentName) {
            const cfg = aiKnowledge.adjustables[paramName];
            if (!cfg) return false;
            const current = getCurrentSliderValue(cfg.sliderId);
            if (current === null) {
                editor.speakThai(randomResponse('cantAdjustRelative'));
                return false;
            }
            let newVal = current + delta;
            newVal = Math.min(cfg.max, Math.max(cfg.min, newVal));
            newVal = Math.round(newVal / cfg.step) * cfg.step;
            updateSliderValue(cfg.sliderId, newVal);
            
            // เรียก apply function ที่เกี่ยวข้อง
            if (paramName === 'amount' && editor.applySharpenWorker) editor.applySharpenWorker();
            else if (paramName === 'radius' && editor.applySharpenWorker) editor.applySharpenWorker();
            else if (paramName === 'threshold' && editor.applySharpenWorker) editor.applySharpenWorker();
            else if (paramName === 'saturation' && editor.applyColorBoost) editor.applyColorBoost();
            else if (paramName === 'brightness' && editor.applyColorBoost) editor.applyColorBoost();
            else if (paramName === 'contrast' && typeof editor.applyColorBoost === 'function') editor.applyColorBoost();
            
            editor.speakThai(randomResponse('confirm') + ` ปรับ${paramName} เป็น ${newVal}`);
            return true;
        }

        // ---------- Intent Parser ขั้นสูง (รองรับ relative, learned synonyms, ขยายบริบท) ----------
        function parseIntent(command, contextIntent = null, contextEntities = null) {
            const lower = command.toLowerCase();
            let intent = null;
            let entities = {};
            const synonyms = getAllSynonyms();
            
            // ตรวจสอบการยืนยัน (ใช่/ไม่) หากกำลังรอบ confirmation
            if (pendingConfirmation) {
                if (/(ใช่|ok|yes|รับ|ตกลง|ยืนยัน|yes|yep|แน่นอน)/.test(lower)) {
                    intent = 'confirm_yes';
                    return { intent, entities };
                } else if (/(ไม่|no|cancel|ยกเลิก|ไม่เอา|ไม่ใช่)/.test(lower)) {
                    intent = 'confirm_no';
                    return { intent, entities };
                }
            }
            
            // คำทักทาย/อำลา/ขอบคุณ (priority)
            if (aiKnowledge.greetings.some(w => lower.includes(w))) {
                intent = 'greeting';
                return { intent, entities };
            }
            if (aiKnowledge.farewells.some(w => lower.includes(w))) {
                intent = 'farewell';
                return { intent, entities };
            }
            if (aiKnowledge.thanks.some(w => lower.includes(w))) {
                intent = 'thank';
                return { intent, entities };
            }
            
            // เรียนรู้คำใหม่ (ถ้าผู้ใช้พูดว่า "จำไว้ว่า X แปลว่า Y")
            const learnMatch = lower.match(/จำไว้ว่า\s+([^\s]+)\s+แปลว่า\s+(.+)/);
            if (learnMatch) {
                let newWord = learnMatch[1].trim();
                let targetAction = learnMatch[2].trim();
                // find action key
                let foundKey = null;
                for (let [key, vals] of Object.entries(synonyms)) {
                    if (vals.some(v => targetAction.includes(v) || targetAction === key)) {
                        foundKey = key;
                        break;
                    }
                }
                if (foundKey) {
                    if (!userSynonyms[foundKey]) userSynonyms[foundKey] = [];
                    if (!userSynonyms[foundKey].includes(newWord)) {
                        userSynonyms[foundKey].push(newWord);
                        localStorage.setItem('voice_synonyms', JSON.stringify(userSynonyms));
                        editor.speakThai(randomResponse('learnSynonym', { word: newWord, action: foundKey }));
                    }
                    intent = 'noop'; // ไม่ทำ action แต่เรียนรู้
                    return { intent, entities };
                }
            }
            
            // ตรวจสอบ action หลักจาก synonyms (รองรับหลายคำ)
            for (let [action, keywords] of Object.entries(synonyms)) {
                if (keywords.some(kw => lower.includes(kw))) {
                    intent = action;
                    break;
                }
            }
            
            // ถ้ายังไม่มี intent ให้ลอง check คำสั่งเดี่ยว (fallback)
            if (!intent) {
                if (/(รีเซ็ต|คืนค่า|reset)/.test(lower)) intent = 'reset';
                else if (/(undo|เลิกทำ|ย้อนกลับ)/.test(lower)) intent = 'undo';
                else if (/(redo|ทำซ้ำ)/.test(lower)) intent = 'redo';
                else if (/(help|ช่วยเหลือ)/.test(lower)) intent = 'help';
                else intent = 'unknown';
            }
            
            // ดึง entities (ตัวเลข, ค่า)
            // ตรวจจับ pattern: "ตั้งค่า X เป็น Y" หรือ "X Y"
            const numberMatch = lower.match(/(\d+(?:\.\d+)?)/);
            if (numberMatch) {
                entities.value = parseFloat(numberMatch[1]);
            }
            
            // ตรวจจับหน่วย (percent, px, etc) แต่เราใช้ตัวเลขอย่างเดียว
            
            // ตรวจสอบ relative adjustment หลังจากรู้ intent
            if (intent === 'sharpen' || intent === 'brightness' || intent === 'contrast' || intent === 'saturation') {
                let relativeDelta = null;
                if (/(เพิ่ม|มากขึ้น|ลด|ลดลง)/.test(lower)) {
                    let paramName = intent; // brightness, contrast, saturation, sharpen->amount
                    if (intent === 'sharpen') paramName = 'amount';
                    relativeDelta = parseRelativeAdjust(command, paramName);
                    if (relativeDelta !== null) {
                        entities.relativeDelta = relativeDelta;
                        entities.paramName = paramName;
                    }
                }
                // ถ้ามีตัวเลขและไม่มี relative (คือ absolute)
                if (entities.value !== undefined && relativeDelta === null) {
                    entities.absolute = entities.value;
                }
            }
            
            // ตรวจจับ reset เฉพาะ (resetColor, resetSharpen)
            if (intent === 'reset') {
                if (lower.includes('สี') || lower.includes('แสง') || lower.includes('color')) intent = 'resetColor';
                else if (lower.includes('คม') || lower.includes('ชาร์ป') || lower.includes('sharpen')) intent = 'resetSharpen';
                else intent = 'resetImage';
            }
            
            return { intent, entities };
        }

        // ---------- Executor พร้อมการขอ confirmation เมื่อจำเป็น ----------
        async function executeIntent(intent, entities) {
            // ตรวจสอบ confirmation flow
            if (intent === 'confirm_yes' && pendingConfirmation) {
                const { intent: pendingIntent, entities: pendingEntities, callback } = pendingConfirmation;
                pendingConfirmation = null;
                // เรียก execute อีกครั้ง
                return await executeIntent(pendingIntent, pendingEntities);
            }
            if (intent === 'confirm_no' && pendingConfirmation) {
                pendingConfirmation = null;
                editor.speakThai("ยกเลิกคำสั่งแล้วค่ะ");
                return true;
            }
            
            // ปกติ
            switch(intent) {
                case 'greeting':
                    editor.speakThai(randomResponse('greeting'));
                    return true;
                case 'farewell':
                    editor.speakThai(randomResponse('farewell'));
                    return true;
                case 'thank':
                    editor.speakThai(randomResponse('thank'));
                    return true;
                case 'help':
                    editor.speakThai(randomResponse('help'));
                    return true;
                case 'undo':
                    editor.undo();
                    editor.speakThai(randomResponse('confirm') + " เลิกทำเรียบร้อย");
                    return true;
                case 'redo':
                    editor.redo();
                    editor.speakThai(randomResponse('confirm') + " ทำซ้ำเรียบร้อย");
                    return true;
                case 'resetImage':
                    editor.resetImage();
                    editor.speakThai(randomResponse('confirm') + " รีเซ็ตเป็นภาพต้นฉบับ");
                    return true;
                case 'resetSharpen':
                    if (editor.resetSharpenEngine) editor.resetSharpenEngine();
                    else editor.speakThai("ไม่พบฟังก์ชันรีเซ็ตความคมชัด");
                    return true;
                case 'resetColor':
                    if (editor.resetColor) editor.resetColor();
                    else editor.speakThai("รีเซ็ตสีเรียบร้อย");
                    return true;
                case 'removeBg':
                    await editor.performAIRemove();
                    return true;
                case 'save':
                    editor.saveImage();
                    return true;
                case 'autoEnhance':
                    if (typeof window.autoEnhanceFn === 'function') window.autoEnhanceFn();
                    else editor.speakThai("โปรดเพิ่มปุ่ม Auto Enhance ก่อนใช้งาน");
                    return true;
                case 'sharpen':
                case 'brightness':
                case 'contrast':
                case 'saturation':
                    // จัดการ relative delta
                    if (entities.relativeDelta !== undefined && entities.paramName) {
                        return await applyRelativeAdjust(entities.paramName, entities.relativeDelta, intent);
                    }
                    // absolute value
                    if (entities.absolute !== undefined) {
                        let paramName = intent;
                        if (intent === 'sharpen') paramName = 'amount';
                        const cfg = aiKnowledge.adjustables[paramName];
                        if (cfg) {
                            let val = entities.absolute;
                            val = Math.min(cfg.max, Math.max(cfg.min, val));
                            val = Math.round(val / cfg.step) * cfg.step;
                            updateSliderValue(cfg.sliderId, val);
                            if (paramName === 'amount' && editor.applySharpenWorker) editor.applySharpenWorker();
                            else if (paramName === 'radius' && editor.applySharpenWorker) editor.applySharpenWorker();
                            else if (paramName === 'threshold' && editor.applySharpenWorker) editor.applySharpenWorker();
                            else if (editor.applyColorBoost) editor.applyColorBoost();
                            editor.speakThai(randomResponse('confirm') + ` ตั้ง${paramName} = ${val}`);
                            return true;
                        }
                    }
                    // ถ้าไม่เจอทั้ง relative และ absolute -> ถามผู้ใช้
                    pendingConfirmation = { intent, entities, callback: null };
                    editor.speakThai(randomResponse('askWhichAction'));
                    return true;
                    
                case 'setAmount':
                case 'setRadius':
                case 'setThreshold':
                    // ถ้ามี entities.value
                    if (entities.value !== undefined) {
                        let paramName = intent.replace('set', '').toLowerCase();
                        const cfg = aiKnowledge.adjustables[paramName];
                        if (cfg) {
                            let val = entities.value;
                            val = Math.min(cfg.max, Math.max(cfg.min, val));
                            updateSliderValue(cfg.sliderId, val);
                            if (paramName === 'amount' && editor.applySharpenWorker) editor.applySharpenWorker();
                            else if (paramName === 'radius' && editor.applySharpenWorker) editor.applySharpenWorker();
                            else if (paramName === 'threshold' && editor.applySharpenWorker) editor.applySharpenWorker();
                            editor.speakThai(randomResponse('confirm') + ` ${paramName} = ${val}`);
                        }
                    } else {
                        editor.speakThai("กรุณาระบุตัวเลขด้วย เช่น 'ตั้งค่ารัศมี 1.5'");
                    }
                    return true;
                    
                case 'toggleZoom':
                    if (editor.toggleZoom) editor.toggleZoom();
                    return true;
                case 'upload':
                    if (editor.uploadBtn) editor.uploadBtn.click();
                    return true;
                case 'noop':
                    return true;
                default:
                    return false;
            }
        }

        // ---------- Override หลัก พร้อมบันทึกประวัติและรองรับ context ----------
        const originalProcess = editor.processVoiceCommand.bind(editor);
        editor.processVoiceCommand = async function(cmd) {
            // บันทึกประวัติ
            conversationHistory.push({ role: 'user', text: cmd, timestamp: Date.now() });
            if (conversationHistory.length > 5) conversationHistory.shift();
            
            // ใช้ context จากคำสั่งก่อนหน้า (ถ้ามี)
            let contextIntent = lastIntent;
            let contextEntities = lastEntities;
            if (contextIntent && (cmd.toLowerCase().includes("อีก") || cmd.toLowerCase().includes("ต่อ") || cmd.toLowerCase().includes("เหมือนเดิม"))) {
                // ถ้าพูดว่า "ทำอีก" หรือ "เพิ่มอีก" ให้ใช้ intent เดิม
                // ทำการ execute ซ้ำ?
                if (contextIntent && lastEntities) {
                    await executeIntent(contextIntent, lastEntities);
                    return;
                }
            }
            
            const { intent, entities } = parseIntent(cmd, contextIntent, contextEntities);
            lastIntent = intent;
            lastEntities = entities;
            
            const executed = await executeIntent(intent, entities);
            if (!executed) {
                // fallback original
                originalProcess(cmd);
            }
        };
        
        // ปรับปรุงการแจ้งเตือน start/end ให้มี animation (ซับซ้อน)
        const originalStart = editor.startVoiceCommand.bind(editor);
        editor.startVoiceCommand = function() {
            if (!editor.recognition) {
                editor.speakThai("เบราว์เซอร์ไม่รองรับการสั่งงานด้วยเสียง");
                return;
            }
            if (editor.isProcessing) {
                editor.speakThai("กำลังประมวลผลภาพ กรุณารอสักครู่");
                return;
            }
            // เพิ่มเอฟเฟกต์การแสดงผล (เปลี่ยนสีพื้นหลังข้อความ)
            const statusDiv = document.getElementById('voiceStatusMsg');
            if (statusDiv) statusDiv.style.transition = "0.3s";
            editor.speakThai("ได้ยินแล้วครับ พูดอะไรก็ได้นะคะ");
            originalStart();
        };
        
        // เพิ่มการแสดงผลแบบ visual feedback ขณะฟัง
        const originalStop = editor.stopVoiceCommand?.bind(editor) || function(){};
        editor.stopVoiceCommand = function() {
            originalStop();
            const statusDiv = document.getElementById('voiceStatusMsg');
            if (statusDiv) statusDiv.style.backgroundColor = "";
        };
        
        // เพิ่มคำแนะนำใน tooltip แบบละเอียด
        const voiceStatusSpan = document.getElementById('voiceStatusMsg');
        if (voiceStatusSpan) {
            voiceStatusSpan.title = "ตัวอย่างขั้นสูง: 'เพิ่มความคมชัดอีก 10%', 'ลดความสว่างลงหน่อย', 'จำไว้ว่า sharpen แปลว่า เพิ่มความคม'";
            voiceStatusSpan.style.cursor = "help";
        }
        
        console.log('✅ Advanced Voice AI Enhancement เปิดใช้งานแล้ว (ซับซ้อน: relative, context, learning)');
        editor.speakThai("ระบบเสียงอัจฉริยะเวอร์ชันขั้นสูงพร้อมใช้งานแล้วนะคะ");
    }
})();